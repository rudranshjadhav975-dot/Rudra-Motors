const cars = [
    {
        name: "Tesla Model S",
        price: "$80,000",
        image: "https://cdn.pixabay.com/photo/2016/11/29/03/53/tesla-1869110_1280.jpg"
    },
    {
        name: "BMW M4",
        price: "$70,000",
        image: "https://cdn.pixabay.com/photo/2019/03/09/09/31/bmw-4046374_1280.jpg"
    },
    {
        name: "Audi R8",
        price: "$120,000",
        image: "https://cdn.pixabay.com/photo/2020/03/22/14/04/audi-4958020_1280.jpg"
    }
];

function displayCars(carArray) {
    const carList = document.getElementById("carList");
    carList.innerHTML = "";

    carArray.forEach(car => {
        const card = document.createElement("div");
        card.className = "car-card";
        
        card.innerHTML = `
            <img src="${car.image}" alt="${car.name}">
            <h3>${car.name}</h3>
            <p><strong>Price:</strong> ${car.price}</p>
            <button onclick="contactSeller('${car.name}')">Contact Seller</button>
        `;

        carList.appendChild(card);
    });
}

function contactSeller(carName) {
    alert(`Contact seller for ${carName} at: 9890050121`);
}

function filterCars() {
    const searchTerm = document.getElementById("searchBox").value.toLowerCase();
    const filtered = cars.filter(car => car.name.toLowerCase().includes(searchTerm));
    displayCars(filtered);
}

displayCars(cars);
let cars = [];

async function loadCars() {
    try {
        const response = await fetch("cars.json"); // Load from external file
        cars = await response.json();
        displayCars(cars);
    } catch (error) {
        console.error("Error loading cars:", error);
    }
}

function displayCars(carArray) {
    const carList = document.getElementById("carList");
    carList.innerHTML = "";

    carArray.forEach(car => {
        const card = document.createElement("div");
        card.className = "car-card";
        
        card.innerHTML = `
            <img src="${car.image}" alt="${car.name}">
            <h3>${car.name}</h3>
            <p><strong>Price:</strong> ${car.price}</p>
            <button onclick="contactSeller('${car.name}', '${car.contact}')">Contact Seller</button>
        `;

        carList.appendChild(card);
    });
}

function contactSeller(carName, contact) {
    alert(`Contact seller for ${carName} at: ${contact}`);
}

function filterCars() {
    const searchTerm = document.getElementById("searchBox").value.toLowerCase();
    const filtered = cars.filter(car => car.name.toLowerCase().includes(searchTerm));
    displayCars(filtered);
}

loadCars();
